<?php
require_once('util.php');
echo "Rebooting server...";
$result = reboot();
?>
