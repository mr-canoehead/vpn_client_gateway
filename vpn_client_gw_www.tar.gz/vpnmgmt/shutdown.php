<?php
require_once('util.php');
echo "Shutting down server...";
$result = shutdown();
?>
