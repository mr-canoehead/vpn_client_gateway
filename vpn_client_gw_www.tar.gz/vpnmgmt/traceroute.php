<?php
echo "<pre id=\"TracerouteText\">" . shell_exec('traceroute 8.8.8.8') . "</pre>";
?>
